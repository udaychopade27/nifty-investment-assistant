from sqlalchemy import (
    Column,
    Integer,
    Date,
    Numeric,
    String,
    TIMESTAMP,
    func,
    ForeignKey,
)
from app.db.base import Base


class ExecutedInvestment(Base):
    __tablename__ = "executed_investments"

    id = Column(Integer, primary_key=True, index=True)

    execution_date = Column(Date, nullable=False)
    month = Column(Date, ForeignKey("monthly_config.month"), nullable=False)

    invested_amount = Column(Integer, nullable=False)
    instrument = Column(String(50), nullable=False)

    execution_price = Column(Numeric(10, 2), nullable=True)
    remarks = Column(String(255), nullable=True)

    created_at = Column(
        TIMESTAMP(timezone=True),
        server_default=func.now(),
        nullable=False,
    )
