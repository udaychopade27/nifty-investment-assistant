from sqlalchemy.orm import Session
from sqlalchemy import func

from app.db.models import ExecutedInvestment
from app.market.nifty_service import NiftyService


def calculate_current_pnl(db: Session) -> dict:
    """
    Estimates unrealized PnL using current NIFTY vs avg buy.
    """

    executions = db.query(ExecutedInvestment).all()

    if not executions:
        return {
            "invested": 0,
            "current_value": 0,
            "pnl": 0,
            "pnl_percent": 0,
        }

    total_invested = sum(e.invested_amount for e in executions)

    nifty = NiftyService().get_today_close()
    current_index = nifty["close"]

    # Assumption: ETF tracks NIFTY
    avg_buy_price = 100  # Placeholder baseline

    current_value = total_invested * (current_index / avg_buy_price)
    pnl = current_value - total_invested
    pnl_percent = (pnl / total_invested) * 100

    return {
        "invested": round(total_invested, 2),
        "current_value": round(current_value, 2),
        "pnl": round(pnl, 2),
        "pnl_percent": round(pnl_percent, 2),
    }
