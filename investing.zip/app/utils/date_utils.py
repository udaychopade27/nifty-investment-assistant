from datetime import date, timedelta
from sqlalchemy.orm import Session

from app.db.models import TradingHoliday


def is_trading_day(check_date: date, db: Session) -> bool:
    """
    Returns True if the date is a valid NSE trading day.
    """
    if check_date.weekday() >= 5:  # Saturday/Sunday
        return False

    holiday = (
        db.query(TradingHoliday)
        .filter(TradingHoliday.holiday_date == check_date)
        .first()
    )
    return holiday is None


def get_trading_days_for_month(
    month_start: date,
    db: Session,
) -> int:
    """
    Calculate actual NSE trading days for a given month.
    Excludes weekends and NSE trading holidays.
    """

    year, month = month_start.year, month_start.month

    if month == 12:
        month_end = date(year + 1, 1, 1)
    else:
        month_end = date(year, month + 1, 1)

    trading_days = 0
    current = month_start

    while current < month_end:
        if is_trading_day(current, db):
            trading_days += 1
        current += timedelta(days=1)

    return trading_days


def trading_days_left_in_month(today: date, db: Session) -> int:
    """
    Returns number of trading days remaining in the current month
    AFTER today.
    """

    year, month = today.year, today.month

    if month == 12:
        month_end = date(year + 1, 1, 1)
    else:
        month_end = date(year, month + 1, 1)

    days_left = 0
    current = today + timedelta(days=1)

    while current < month_end:
        if is_trading_day(current, db):
            days_left += 1
        current += timedelta(days=1)

    return days_left
