from telegram import Update
from telegram.ext import ContextTypes


async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        """
🤖 *Nifty Investment Assistant – Help*

Below are all available commands:

📌 *Capital Setup*
/setcapital 10000  
→ Set monthly capital  
Example: `/setcapital 15000`

📊 *Daily Info*
/status  
→ Shows today’s investment decision & remaining capital

📈 *Monthly Info*
/summary  
→ Shows current month progress

💰 *Confirm Execution*
/confirm 500  
→ Confirm how much you actually invested today  
(Partial allowed, but not more than suggested)

↩️ *Undo Execution*
/undo  
→ Undo today’s last confirmed investment

📉 *Portfolio PnL*
/pnl  
→ Shows total invested & estimated profit/loss

🆘 *Help*
/help  
→ Show this help message

⚠️ *Notes*
• Decisions are *suggestions*, not auto-trades  
• You stay in control  
• Month-end deployment is automatic  

Happy disciplined investing 🚀
        """,
        parse_mode="Markdown",
    )
