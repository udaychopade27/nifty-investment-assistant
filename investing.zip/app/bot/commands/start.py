from telegram import Update
from telegram.ext import ContextTypes


async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "🤖 Nifty Investment Assistant is LIVE.\n\n"
        "Available commands:\n"
        "/setcapital <amount>\n"
        "/status\n"
        "/summary\n"
        "/confirm   <amount> here needs to add how much you invested today\n"
        "/pnl\n"
        "/undo\n"
        "/help"
    )
