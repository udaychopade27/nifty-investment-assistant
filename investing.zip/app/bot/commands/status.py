from telegram import Update
from telegram.ext import ContextTypes

from app.db.db import SessionLocal
from app.engine.daily_decision import decide_investment_for_today


async def status_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    db = SessionLocal()
    try:
        decision = decide_investment_for_today(db)

        # -----------------------------
        # Normalize decision result
        # -----------------------------
        if isinstance(decision, dict):
            nifty_change = decision.get("nifty_change")
            suggested_amount = (
                decision.get("suggested_amount")
                or decision.get("amount")
                or decision.get("daily_amount")
            )
            reason = decision.get("decision_reason") or decision.get("reason")
        else:
            # SQLAlchemy model fallback
            nifty_change = getattr(decision, "nifty_change", None)
            suggested_amount = getattr(decision, "suggested_amount", None)
            reason = getattr(decision, "decision_reason", None)

        if suggested_amount is None:
            raise KeyError("suggested_amount missing in decision payload")

        await update.message.reply_text(
            "📊 *Today's Decision*\n\n"
            f"📉 NIFTY Change: {nifty_change}%\n"
            f"💰 Suggested Amount: ₹{suggested_amount}\n"
            f"📝 Reason: {reason}",
            parse_mode="Markdown",
        )

    except RuntimeError as e:
        await update.message.reply_text(
            "⚠️ *Action Required*\n\n"
            f"{str(e)}\n\n"
            "Use:\n/setcapital <amount>\n\n"
            "Example:\n/setcapital 10000",
            parse_mode="Markdown",
        )

    except Exception as e:
        # 👇 hard safety net (prevents bot crashes)
        await update.message.reply_text(
            "❌ Failed to fetch today's decision.\n"
            "Please try again later."
        )
        raise  # keep traceback in logs

    finally:
        db.close()
