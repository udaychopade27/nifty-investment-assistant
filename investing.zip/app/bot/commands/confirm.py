import logging
from datetime import date

from telegram import Update
from telegram.ext import ContextTypes

from app.db.db import SessionLocal
from app.db.models import DailyDecision, ExecutedInvestment

logger = logging.getLogger(__name__)


async def confirm_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args or len(context.args) != 1:
        await update.message.reply_text(
            "❌ Usage:\n/confirm <amount>\n\nExample:\n/confirm 500"
        )
        return

    try:
        amount = int(context.args[0])
        if amount <= 0:
            raise ValueError
    except ValueError:
        await update.message.reply_text("❌ Invalid amount.")
        return

    today = date.today()
    db = SessionLocal()

    try:
        decision = (
            db.query(DailyDecision)
            .filter(DailyDecision.decision_date == today)
            .first()
        )

        if not decision:
            await update.message.reply_text("❌ No decision found for today.")
            return

        # 🔒 Enforce upper limit
        if amount > decision.suggested_amount:
            await update.message.reply_text(
                f"❌ Cannot confirm more than suggested.\n\n"
                f"💡 Suggested: ₹{decision.suggested_amount}\n"
                f"❌ Attempted: ₹{amount}"
            )
            return

        execution = ExecutedInvestment(
            execution_date=today,
            month=decision.month,
            invested_amount=amount,
            instrument="ETF / INDEX FUND",
            execution_price=None,
            remarks="Confirmed via Telegram",
        )

        db.add(execution)
        db.commit()

        await update.message.reply_text(
            f"✅ *Investment Confirmed*\n\n"
            f"📅 Date: {today}\n"
            f"💰 Amount Invested: ₹{amount}",
            parse_mode="Markdown",
        )

    except Exception:
        logger.exception("Confirm failed")
        await update.message.reply_text("❌ Failed to confirm investment.")
    finally:
        db.close()
