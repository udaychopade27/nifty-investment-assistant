import logging
from typing import Optional, Set

from telegram.ext import Application, CommandHandler

from app.core.config import get_settings

# -------------------------------
# Import command handlers
# -------------------------------
from app.bot.commands.start import start_command
from app.bot.commands.help import help_command
from app.bot.commands.set_capital import set_capital_command
from app.bot.commands.status import status_command
from app.bot.commands.summary import summary_command
from app.bot.commands.confirm import confirm_command
from app.bot.commands.undo import undo_command
from app.bot.commands.pnl import pnl_command

logger = logging.getLogger(__name__)
settings = get_settings()


class TelegramBot:
    """
    Async Telegram bot integrated with FastAPI lifecycle.
    Polling enabled. Modular command architecture.
    """

    def __init__(self):
        self.token = settings.TELEGRAM_BOT_TOKEN
        self.application: Optional[Application] = None
        self.chat_ids: Set[int] = set()
        self.is_running = False

    # ==================================================
    # Register handlers
    # ==================================================

    def setup_handlers(self):
        # Core
        self.application.add_handler(CommandHandler("start", start_command))
        self.application.add_handler(CommandHandler("help", help_command))

        # Capital & Decisions
        self.application.add_handler(CommandHandler("setcapital", set_capital_command))
        self.application.add_handler(CommandHandler("status", status_command))
        self.application.add_handler(CommandHandler("summary", summary_command))

        # Execution flow
        self.application.add_handler(CommandHandler("confirm", confirm_command))
        self.application.add_handler(CommandHandler("undo", undo_command))

        # Reports
        self.application.add_handler(CommandHandler("pnl", pnl_command))

        logger.info("🤖 Telegram handlers registered")

    # ==================================================
    # Lifecycle
    # ==================================================

    async def start(self):
        if not self.token or self.is_running:
            logger.warning("Telegram bot not started (missing token or already running)")
            return

        self.application = Application.builder().token(self.token).build()
        self.setup_handlers()

        # Init + start app
        await self.application.initialize()
        await self.application.start()

        # 🔑 Enable polling (REQUIRED)
        if self.application.updater:
            await self.application.updater.start_polling()

        self.is_running = True
        logger.info("🤖 Telegram bot started (polling active)")

    async def stop(self):
        if not self.application or not self.is_running:
            return

        try:
            if self.application.updater:
                await self.application.updater.stop()

            await self.application.shutdown()
            self.is_running = False
            logger.info("🤖 Telegram bot stopped")

        except Exception:
            logger.exception("Error stopping Telegram bot")


# Singleton
telegram_bot = TelegramBot()
