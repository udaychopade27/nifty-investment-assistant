import logging
import requests

from app.core.config import get_settings

logger = logging.getLogger(__name__)
settings = get_settings()


def send_telegram_message(message: str) -> bool:
    """
    Sends a message to Telegram chat.
    Returns True on success, False otherwise.
    """

    if not settings.TELEGRAM_BOT_TOKEN or not settings.TELEGRAM_CHAT_ID:
        logger.warning(
            "Telegram not configured | token=%s chat_id=%s",
            bool(settings.TELEGRAM_BOT_TOKEN),
            settings.TELEGRAM_CHAT_ID,
        )
        return False

    url = (
        f"https://api.telegram.org/bot"
        f"{settings.TELEGRAM_BOT_TOKEN}/sendMessage"
    )

    payload = {
        "chat_id": settings.TELEGRAM_CHAT_ID,
        "text": message,
        "parse_mode": "Markdown",
        "disable_web_page_preview": True,
    }

    try:
        response = requests.post(url, json=payload, timeout=10)
        response.raise_for_status()

        logger.info(
            "📨 Telegram alert sent | chat_id=%s",
            settings.TELEGRAM_CHAT_ID,
        )
        return True

    except Exception as e:
        logger.exception(
            "❌ Failed to send Telegram alert | error=%s",
            e,
        )
        return False
